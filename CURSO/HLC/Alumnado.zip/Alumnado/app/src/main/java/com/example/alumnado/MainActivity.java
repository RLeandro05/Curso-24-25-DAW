package com.example.alumnado;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    private TextView tv;
    private ListView lv;
    private String nombres[] = {"Álvaro", "Javier", "Marina", "Natalia", "Francisco", "David", "Fernando"};
    private String notas[] = {"7", "10", "2", "8", "3", "10", "4,9"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);

            return insets;
        });

        tv = findViewById(R.id.tv);
        lv = findViewById(R.id.lv);

        ArrayAdapter<String> adapter = new ArrayAdapter<String>(this, R.layout.list_estilo,
                nombres);
        lv.setAdapter(adapter);

        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                tv.setText("La nota de "+lv.getItemAtPosition(i)+" es "+notas[i]);
            }
        });
    }
}