<?php
    require_once("conexion.php"); //Incluir la conexión
?>