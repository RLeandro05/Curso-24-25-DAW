<?php
    require_once "Data.php";

    //Actividad 3: Añadir una nueva comunidad y mostrarlos por pantalla

    $comunidades += ["Madrid"];

    echo "<pre>";
    print_r($comunidades[0]);
    echo "</pre>";
?>